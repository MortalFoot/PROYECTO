import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CaratulAarcticPage } from './caratul-aarctic';

@NgModule({
  declarations: [
    CaratulAarcticPage,
  ],
  imports: [
    IonicPageModule.forChild(CaratulAarcticPage),
  ],
})
export class CaratulAarcticPageModule {}
