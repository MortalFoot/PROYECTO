import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CaratulAcurePage } from './caratul-acure';

@NgModule({
  declarations: [
    CaratulAcurePage,
  ],
  imports: [
    IonicPageModule.forChild(CaratulAcurePage),
  ],
})
export class CaratulAcurePageModule {}
