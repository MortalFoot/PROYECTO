import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CaratulaBrothersPage } from './caratula-brothers';

@NgModule({
  declarations: [
    CaratulaBrothersPage,
  ],
  imports: [
    IonicPageModule.forChild(CaratulaBrothersPage),
  ],
})
export class CaratulaBrothersPageModule {}
