import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Caratula1Page } from './caratula1';

@NgModule({
  declarations: [
    Caratula1Page,
  ],
  imports: [
    IonicPageModule.forChild(Caratula1Page),
  ],
})
export class Caratula1PageModule {}
