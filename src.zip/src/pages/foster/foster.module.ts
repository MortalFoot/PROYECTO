import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FosterPage } from './foster';

@NgModule({
  declarations: [
    FosterPage,
  ],
  imports: [
    IonicPageModule.forChild(FosterPage),
  ],
})
export class FosterPageModule {}
