import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FwdPage } from './fwd';

@NgModule({
  declarations: [
    FwdPage,
  ],
  imports: [
    IonicPageModule.forChild(FwdPage),
  ],
})
export class FwdPageModule {}
