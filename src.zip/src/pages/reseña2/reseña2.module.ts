import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Reseña2Page } from './reseña2';

@NgModule({
  declarations: [
    Reseña2Page,
  ],
  imports: [
    IonicPageModule.forChild(Reseña2Page),
  ],
})
export class Reseña2PageModule {}
