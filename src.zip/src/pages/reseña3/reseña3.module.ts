import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Reseña3Page } from './reseña3';

@NgModule({
  declarations: [
    Reseña3Page,
  ],
  imports: [
    IonicPageModule.forChild(Reseña3Page),
  ],
})
export class Reseña3PageModule {}
