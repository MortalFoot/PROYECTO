import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Reseña4Page } from './reseña4';

@NgModule({
  declarations: [
    Reseña4Page,
  ],
  imports: [
    IonicPageModule.forChild(Reseña4Page),
  ],
})
export class Reseña4PageModule {}
