import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReseñacurePage } from './reseñacure';

@NgModule({
  declarations: [
    ReseñacurePage,
  ],
  imports: [
    IonicPageModule.forChild(ReseñacurePage),
  ],
})
export class ReseñacurePageModule {}
