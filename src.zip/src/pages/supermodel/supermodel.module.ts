import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SupermodelPage } from './supermodel';

@NgModule({
  declarations: [
    SupermodelPage,
  ],
  imports: [
    IonicPageModule.forChild(SupermodelPage),
  ],
})
export class SupermodelPageModule {}
